package exercicioRafael;

public interface FigurasGeometricas {
	
	public String getNomeFigura();
	
	public int getArea();
	
	public int getPerimetro();
	
}
