package Model;

public class ModelExibe {
	private Integer cpf;
	
	public ModelExibe() {
		super();
	}

	public ModelExibe(Integer cpf) {
		super();
		this.cpf = cpf;
	}

	public Integer getCPF() {
		return cpf;
	}

	public void setCPF(Integer cpf) {
		this.cpf = cpf;
	}
	
	
}

