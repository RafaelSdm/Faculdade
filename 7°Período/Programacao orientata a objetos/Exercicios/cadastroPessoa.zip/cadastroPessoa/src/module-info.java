/**
 * 
 */
/**
 * @author Bernardo
 *
 */
module cadastroPessoa {
	requires java.sql;
}