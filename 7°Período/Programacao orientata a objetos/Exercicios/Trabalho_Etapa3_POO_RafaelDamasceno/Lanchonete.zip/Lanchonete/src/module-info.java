/**
 * 
 */
/**
 * @author NZXT
 *
 */
module Lanchonete {
	requires java.desktop;
}