#include <stdio.h>

void dobrar (n1){
  printf("O dobro de %d é: %d\n\n\n\n", n1, n1*2);
  
}

void somar(n1, n2){
  printf("A soma dos numeros %d + %d = %d", n1, n2, n1 + n2);
}

void maiorNumero(n1, n2){
  if(n1 > n2){
    printf("O numero %d é maior que o numero %d ", n1, n2);
  }else if(n2 > n1){
    printf("O numero %d é maior que o numero %d", n2, n1);
  }else{
    printf("Os numeros %d e o %d são iguais", n1, n2);
  }
}



int main(void) {
  printf("Bem vindo!\n");

  int i = 0;
  int resp = 0;
  int n1 = 0;
  int n2 = 0;
  
  while (i != 1){
    printf("\n----------------------------\n");
    printf("\n1 - Calcular o Dobro\n");
    printf("\n2 - Somar dois numeros\n");
    printf("\n3 - Número maior\n");
    printf("\n0 - Sair\n");
    scanf("%d", &resp);
    printf("\n------------------------------\n");
    
    switch(resp){
      case 1:
        //printf("Dobro");
        printf("Informe o numero desejado: ");
        scanf("%d", &n1 );
        dobrar(n1);
          
         

          
        break;

      case 2:
        //printf("Somar");
        printf("Informe o primeiro numero: \n");
        scanf("%d", &n1);
        printf("Informe o segundo numero: \n");
        scanf("%d", &n2);
        somar(n1, n2);
        break;
      case 3:
        //printf("Maior numero");
        printf("Informe o primeiro numero: \n");
        scanf("%d", &n1);
        printf("Informe o segundo numero: \n");
        scanf("%d", &n2);
        maiorNumero(n1,n2);
        break;
      case 0:
        i = 1;
        printf("Saiu");
        break;

    }
  }
  return 0;
}