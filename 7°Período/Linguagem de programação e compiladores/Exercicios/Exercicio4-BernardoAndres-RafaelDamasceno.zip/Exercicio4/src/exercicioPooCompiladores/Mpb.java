package exercicioPooCompiladores;

public class Mpb extends Musicais {

	public Mpb(Integer ano, Double tempoMusica) {
		super(ano, tempoMusica);
		// TODO Auto-generated constructor stub
	}
	
	

}
