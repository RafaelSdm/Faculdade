package exercicioPooCompiladores;

public class FilmeComedia extends Filmes {

	public FilmeComedia(Integer ano, String generoFilme) {
		super(ano, generoFilme);
		// TODO Auto-generated constructor stub
	}
	
	

}
