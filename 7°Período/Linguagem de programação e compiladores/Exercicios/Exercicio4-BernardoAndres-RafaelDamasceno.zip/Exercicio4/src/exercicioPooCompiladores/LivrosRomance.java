package exercicioPooCompiladores;

public class LivrosRomance extends Escritas {

	public LivrosRomance(Integer ano, Integer numeorsPaginas) {
		super(ano, numeorsPaginas);
	}
	
	

}
