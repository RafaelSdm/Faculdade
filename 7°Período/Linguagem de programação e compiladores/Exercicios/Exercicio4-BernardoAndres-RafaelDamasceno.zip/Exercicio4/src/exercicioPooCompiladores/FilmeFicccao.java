package exercicioPooCompiladores;

public class FilmeFicccao extends Filmes {

	public FilmeFicccao(Integer ano, String generoFilme) {
		super(ano, generoFilme);
		// TODO Auto-generated constructor stub
	}
	
	

}
