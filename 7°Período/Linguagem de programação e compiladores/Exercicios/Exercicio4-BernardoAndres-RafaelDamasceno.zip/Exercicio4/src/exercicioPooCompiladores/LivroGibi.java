package exercicioPooCompiladores;

public class LivroGibi extends Escritas{

	public LivroGibi(Integer ano, Integer numeorsPaginas) {
		super(ano, numeorsPaginas);
	}
	
	

}
