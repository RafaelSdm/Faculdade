package exercicioPooCompiladores;

public class Rock extends Musicais {

	public Rock(Integer ano, Double tempoMusica) {
		super(ano, tempoMusica);
	}
	

}
