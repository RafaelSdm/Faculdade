package exercicioPooCompiladores;

public abstract class Obras {
	
	private Integer ano;
	
	public Obras(Integer ano) {
		this.setAno(ano);
	}

	public Integer getAno() {
		return ano;
	}

	public void setAno(Integer ano) {
		this.ano = ano;
	}


}


