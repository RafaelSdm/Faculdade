package exercicioPooCompiladores;

public class LivroFiccao extends Escritas {

	public LivroFiccao(Integer ano, Integer numeorsPaginas) {
		super(ano, numeorsPaginas);
	}
	
	

}
