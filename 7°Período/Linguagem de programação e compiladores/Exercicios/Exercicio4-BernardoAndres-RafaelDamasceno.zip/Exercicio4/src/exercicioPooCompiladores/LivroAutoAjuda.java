package exercicioPooCompiladores;

public class LivroAutoAjuda extends Escritas {

	public LivroAutoAjuda(Integer ano, Integer numeorsPaginas) {
		super(ano, numeorsPaginas);
	}
	
	

}
