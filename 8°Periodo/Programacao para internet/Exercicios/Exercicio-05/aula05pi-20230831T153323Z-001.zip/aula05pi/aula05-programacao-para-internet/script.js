


function verProduto(){

    console.log('testetete')
    var posicao = document.getElementById('produtos')
    var id = document.getElementById('identificador').value

    console.log(posicao)

    document.getElementById('produtos').innerHTML = `<p>${id}</p>`

    
}