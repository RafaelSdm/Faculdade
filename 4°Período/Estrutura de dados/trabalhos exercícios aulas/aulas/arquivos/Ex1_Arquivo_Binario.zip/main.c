#include <stdio.h>
#include <stdlib.h>
#include <strings.h>

typedef struct{
    int cod;
    char nome[50];
    int pontuacao;
}TipoTime;

void gravar(FILE *arquivo, TipoTime time){
    //posiciona o ponteiro no final do arquivo
    fseek(arquivo, 0, SEEK_END);
    fwrite(&time, sizeof(TipoTime), 1, arquivo);
}

void imprimir(FILE *arquivo, int qtde){
    TipoTime times[qtde];
    int i;
    //posiciona o ponteiro no inicio do arquivo
    fseek(arquivo, 0, SEEK_SET);
    fread(&times, sizeof(TipoTime), qtde, arquivo);

    for(i=0; i<qtde; i++){
        printf("%d - %s : %d pontos\n", times[i].cod, times[i].nome, times[i].pontuacao);
    }
}

int main()
{
    FILE *arquivo;
    TipoTime time;
    int i;

    arquivo = fopen("times.dat", "w+b");

    if(arquivo==NULL){
        printf("Falha ao ler o arquivo");
        return 1;
    }

    for (i=0; i<5; i++){
        printf("Informe o codigo do time: ");
        scanf("%d", &time.cod);
        getchar();
        printf("Informe o nome do time: ");
        fgets(time.nome, 50, stdin);
        printf("Informe a pontuacao do time: ");
        scanf("%d", &time.pontuacao);

        time.nome[strlen(time.nome)-1] = '\0';

        gravar(arquivo, time);

    }

    imprimir(arquivo, 5);

    fclose(arquivo);

    return 0;
}
