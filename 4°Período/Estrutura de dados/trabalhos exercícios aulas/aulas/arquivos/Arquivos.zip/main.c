#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *arquivo;
    char c;

    arquivo = fopen("arquivo_gravado.txt", "w");

    if(arquivo == NULL){
        printf("Falha ao abrir o arquivo.");
        return 1;
    }

    fprintf(arquivo, "Exemplo de conteudo no arquivo");

    fclose(arquivo);


    arquivo = fopen("arquivo_gravado.txt", "r");

    c = fgetc(arquivo);

    while (feof(arquivo)==0){
        printf("%c", c);
        c = fgetc(arquivo);
    }

    fclose(arquivo);

    return 0;
}
